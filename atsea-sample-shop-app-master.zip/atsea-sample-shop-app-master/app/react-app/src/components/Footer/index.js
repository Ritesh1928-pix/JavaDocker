import React from 'react';
import './styles.css'

const Footer = () => {
  return (
    <div className='footer'>
      <div className='copyright'>
        &copy;  2017
            </div>
    </div>

  );
}

export default Footer;
